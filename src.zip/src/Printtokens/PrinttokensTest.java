package Printtokens;

import static org.junit.jupiter.api.Assertions.*;

import java.util.function.BooleanSupplier;

import static Printtokens.Printtokens.*;

import org.junit.jupiter.api.Test;
import java.io.*;



class PrinttokensTest {

	//please update this with your path with exact \\ like stated below
	String path = "C:\\Users\\Sindhu parajuli\\eclipse-workspace";
	

	@Test
	void testGet_token() throws IOException {
		Printtokens printtokens = new Printtokens();
        assertNull(printtokens.get_token(getBufferedReader("")));
        assertNull(printtokens.get_token(getBufferedReader("\n")));
        assertEquals(",", printtokens.get_token(getBufferedReader(",")));
        assertEquals(";", printtokens.get_token(getBufferedReader(";")));
        assertEquals("(", printtokens.get_token(getBufferedReader("(")));
        assertEquals(")", printtokens.get_token(getBufferedReader(")")));
        assertEquals("[", printtokens.get_token(getBufferedReader("[")));
        assertEquals("]", printtokens.get_token(getBufferedReader("]")));
        assertEquals("/", printtokens.get_token(getBufferedReader("/")));
        assertEquals("*", printtokens.get_token(getBufferedReader("*")));
        assertEquals("#", printtokens.get_token(getBufferedReader("#")));
        assertEquals("`", printtokens.get_token(getBufferedReader("`")));
        assertEquals("\"", printtokens.get_token(getBufferedReader("\"")));
        assertEquals("S", printtokens.get_token(getBufferedReader("S")));
        assertEquals("Sam", printtokens.get_token(getBufferedReader("Sam")));
        assertEquals("\"Sandy\"", printtokens.get_token(getBufferedReader("\"Sandy\"")));
        assertEquals("\"Sandy]\"", printtokens.get_token(getBufferedReader("\"Sandy]\"")));
        assertEquals("Sandy", printtokens.get_token(getBufferedReader("Sandy")));
        assertEquals(";Sandy", printtokens.get_token(getBufferedReader(";Sandy")));
        assertEquals("Sandy", printtokens.get_token(getBufferedReader("Sandy(")));
        assertEquals("Sandy", printtokens.get_token(getBufferedReader("Sandy;")));

    }
	
	


    private BufferedReader getBufferedReader(String input) {
        Reader reader = new StringReader(input);
        BufferedReader br = new BufferedReader(reader);
        return new BufferedReader(br);
    }
	

	@Test
	void testIs_token_end() {
		assertTrue(is_token_end(99, -1));
		assertFalse(is_token_end(1, 99));
		assertTrue(is_token_end(1, 13));
		assertTrue(is_token_end(2, 13));
		assertFalse(is_token_end(2, 99));
		assertTrue(is_token_end(5, 40));
		assertTrue(is_token_end(30, 32));
		assertFalse(is_token_end(5, 90));
		assertTrue(is_token_end(0, 13));
		//fail("Not yet implemented");
	}

	@Test
	void testIs_keyword() {
		assertEquals(true, Printtokens.is_keyword("and"));
		assertEquals(true, Printtokens.is_keyword("or"));
		assertEquals(true, Printtokens.is_keyword("if"));
		assertEquals(true, Printtokens.is_keyword("xor"));
		assertEquals(true, Printtokens.is_keyword("lambda"));
		assertEquals(true, Printtokens.is_keyword("=>"));
		assertEquals(false, Printtokens.is_keyword("sandy"));
		//fail("Not yet implemented");
	}

	@Test
	void testIs_num_constant() {
		assertTrue(is_num_constant("99"));
		assertFalse(is_num_constant("Sandy"));
		assertFalse(is_num_constant("9B"));
		
	}

	@Test
	void testIs_identifier() {
		assertTrue( is_identifier("b9\0"));
		assertFalse( is_identifier("9"));
		assertFalse( is_identifier("p["));
		assertTrue( is_identifier("b"));
		
	}

	@Test
	void whenEmptyFile_shouldReturnOutputEmpty() {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		System.setOut(new PrintStream(stream));
		
		String[] args = {path.concat("\\Printtokens\\src\\Printtokens\\emptyfile.txt")};
		main(args);
		assertEquals("", stream.toString());
	}
	@Test
	void whenFilewithasterisk() {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		System.setOut(new PrintStream(stream));
		String[] args = {path.concat("\\Printtokens\\src\\Printtokens\\HCI.txt")};
		main(args);

		assertEquals("error,\"*\".\n", stream.toString());
		assertNotEquals("", stream.toString());
	}
	
	@Test
	void InvalidToken() {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		System.setOut(new PrintStream(stream));
		String[] args = {"C:\\Users\\Test\\eclipse-workspace\\Printtokens\\src\\Printtokens\\HCIadsdsaf.txt","C:\\Users\\Test\\eclipse-workspace\\Printtokens\\src\\Printtokens\\HCITwoBigBracket.txt"};
		main(args);

		assertEquals("Error! Please give the token stream\n", stream.toString());
		assertNotEquals("", stream.toString());
	}
	
	@Test
	void Filename() {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		System.setOut(new PrintStream(stream));
		String[] args = {path.concat("\\Printtokens\\src\\Printtokens\\.txt")};
		main(args);

		assertEquals("", stream.toString());
	}
	
	
	
	
	
	@Test
	void whenFilewithsmallbracket() {
		ByteArrayOutputStream streams = new ByteArrayOutputStream();
		System.setOut(new PrintStream(streams));
		String[] args = {path.concat("\\Printtokens\\src\\Printtokens\\HCISmallBracket.txt")};

		main(args);
		
		assertEquals("lparen.\n", streams.toString());
        assertNotEquals("error,\"*\".\n", streams.toString());
        assertNotEquals("", streams.toString());
		}
	
	@Test
	void whenFilewithBigbracket() {
		ByteArrayOutputStream streams = new ByteArrayOutputStream();
		System.setOut(new PrintStream(streams));
		String[] args = {path.concat("\\Printtokens\\src\\Printtokens\\HCITwoBigBracket.txt")};
		main(args);
		
		assertEquals("lsquare.\n" +
				"lsquare.\n", streams.toString());
    
		}
	
	

	
	@Test
	void testIs_str_constant()
	{
		assertTrue(is_str_constant("\"\""));
		assertFalse(is_str_constant("9"));
		assertTrue(is_str_constant("\"sandy\""));
		assertFalse(is_str_constant("\""));
	}

	

}
